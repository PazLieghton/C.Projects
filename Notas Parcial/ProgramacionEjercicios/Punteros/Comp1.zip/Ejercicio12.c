#include <stdio.h>

struct {
  union {
    char a, b;
    int c;
  }d;
int e [5];
}f,*p = &f; //En struct se puede llamar puntero

int main(){
  printf("\n Parte a p->b: %c\n", p->d.b); //Devuelve Null a) es verdadero
  //NO FUNCIONA LA FLECHA PORQUE PASO DE STRUCT A UNION

  return 0;
}
